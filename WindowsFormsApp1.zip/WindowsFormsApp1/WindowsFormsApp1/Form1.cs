﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        //vincent halim 016
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection connect;
        MySqlCommand comand;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();
        DataTable team = new DataTable();
        DataTable team2 = new DataTable();
        string query;
        string isi;
        

        private void Form1_Load(object sender, EventArgs e)
        {
            connect = new MySqlConnection("server = localhost; uid = root; pwd = isbmantap; database = premier_league");
            connect.Open();
            connect.Close();
            query = "select * from team";
            comand = new MySqlCommand(query,connect);
            adapter = new MySqlDataAdapter(comand);
            adapter.Fill(team);
            adapter.Fill(team2);
            cb_home.DataSource = team;
            cb_home.DisplayMember = "team_name";
            cb_home.Text = " ";
            
            

            cb_away.DataSource = team2;
            cb_away.DisplayMember = "team_name";
            cb_away.Text = " ";

            cb_team.Items.Add(cb_home.Text);

            dt.Columns.Add("minute");
            dt.Columns.Add("team");
            dt.Columns.Add("player");
            dt.Columns.Add("type");
            dgv_detail.DataSource = dt;
        }

        private void cb_home_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_home.Text == cb_away.Text)
            {
                MessageBox.Show("g boleh tim sama");
            }
            if(cb_home != null & cb_away != null )
            {
                cb_team.Items.Clear();
                cb_team.Items.Add(cb_home.Text);
                cb_team.Items.Add(cb_away.Text);
            }
        }

        private void cb_away_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_away.Text == cb_home.Text)
            {
                MessageBox.Show("g boleh tim sama");
                
            }
            if (cb_home != null & cb_away != null)
            {
                cb_team.Items.Clear();
                cb_team.Items.Add(cb_home.Text);
                cb_team.Items.Add(cb_away.Text);
            }
        }
        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            DataTable player = new DataTable();
            string query = "select player_name from player left join team on team.team_name = '" + cb_team.Text + "' where player.team_id = team.team_id AND status = 1 group by player_name";
            comand = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(comand);
            adapter.Fill(player);
            cb_player.DataSource = player;
            cb_player.DisplayMember = "player";
            cb_player.ValueMember = "player_name";
        }


        private void cb_player_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if(txt_minute == null && cb_team == null && cb_player == null && cb_type == null)
            {
                MessageBox.Show("ada yang kosong");
            }
            else
            {
               
                dt.Rows.Add(txt_minute.Text, cb_team.Text, cb_player.Text, cb_type.Text);
                txt_minute.Text = null;
                cb_team.SelectedItem = null;
                cb_player.SelectedItem = null;
                cb_type.SelectedItem = null;
            }
            
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            foreach(DataGridViewRow dr in dgv_detail.SelectedRows)
            {
                dgv_detail.Rows.RemoveAt(dr.Index);
            }
            
        }
    }
}
