﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_id = new System.Windows.Forms.Label();
            this.lbl_home = new System.Windows.Forms.Label();
            this.lbl_date = new System.Windows.Forms.Label();
            this.lbl_away = new System.Windows.Forms.Label();
            this.lbl_minute = new System.Windows.Forms.Label();
            this.lbl_team = new System.Windows.Forms.Label();
            this.lbl_player = new System.Windows.Forms.Label();
            this.lbl_type = new System.Windows.Forms.Label();
            this.dgv_detail = new System.Windows.Forms.DataGridView();
            this.txt_id = new System.Windows.Forms.TextBox();
            this.txt_minute = new System.Windows.Forms.TextBox();
            this.cb_home = new System.Windows.Forms.ComboBox();
            this.cb_away = new System.Windows.Forms.ComboBox();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_insert = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_detail)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_id
            // 
            this.lbl_id.AutoSize = true;
            this.lbl_id.Location = new System.Drawing.Point(205, 94);
            this.lbl_id.Name = "lbl_id";
            this.lbl_id.Size = new System.Drawing.Size(105, 25);
            this.lbl_id.TabIndex = 0;
            this.lbl_id.Text = "match id :";
            // 
            // lbl_home
            // 
            this.lbl_home.AutoSize = true;
            this.lbl_home.Location = new System.Drawing.Point(159, 214);
            this.lbl_home.Name = "lbl_home";
            this.lbl_home.Size = new System.Drawing.Size(128, 25);
            this.lbl_home.TabIndex = 1;
            this.lbl_home.Text = "Team Home";
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.Location = new System.Drawing.Point(978, 94);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(122, 25);
            this.lbl_date.TabIndex = 2;
            this.lbl_date.Text = "Match Date";
            // 
            // lbl_away
            // 
            this.lbl_away.AutoSize = true;
            this.lbl_away.Location = new System.Drawing.Point(978, 214);
            this.lbl_away.Name = "lbl_away";
            this.lbl_away.Size = new System.Drawing.Size(124, 25);
            this.lbl_away.TabIndex = 3;
            this.lbl_away.Text = "Team Away";
            // 
            // lbl_minute
            // 
            this.lbl_minute.AutoSize = true;
            this.lbl_minute.Location = new System.Drawing.Point(1445, 468);
            this.lbl_minute.Name = "lbl_minute";
            this.lbl_minute.Size = new System.Drawing.Size(77, 25);
            this.lbl_minute.TabIndex = 4;
            this.lbl_minute.Text = "Minute";
            // 
            // lbl_team
            // 
            this.lbl_team.AutoSize = true;
            this.lbl_team.Location = new System.Drawing.Point(1445, 574);
            this.lbl_team.Name = "lbl_team";
            this.lbl_team.Size = new System.Drawing.Size(66, 25);
            this.lbl_team.TabIndex = 5;
            this.lbl_team.Text = "Team";
            // 
            // lbl_player
            // 
            this.lbl_player.AutoSize = true;
            this.lbl_player.Location = new System.Drawing.Point(1446, 716);
            this.lbl_player.Name = "lbl_player";
            this.lbl_player.Size = new System.Drawing.Size(73, 25);
            this.lbl_player.TabIndex = 6;
            this.lbl_player.Text = "Player";
            // 
            // lbl_type
            // 
            this.lbl_type.AutoSize = true;
            this.lbl_type.Location = new System.Drawing.Point(1446, 842);
            this.lbl_type.Name = "lbl_type";
            this.lbl_type.Size = new System.Drawing.Size(60, 25);
            this.lbl_type.TabIndex = 7;
            this.lbl_type.Text = "Type";
            // 
            // dgv_detail
            // 
            this.dgv_detail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_detail.Location = new System.Drawing.Point(126, 458);
            this.dgv_detail.Name = "dgv_detail";
            this.dgv_detail.RowHeadersWidth = 82;
            this.dgv_detail.RowTemplate.Height = 33;
            this.dgv_detail.Size = new System.Drawing.Size(1188, 683);
            this.dgv_detail.TabIndex = 8;
            // 
            // txt_id
            // 
            this.txt_id.Enabled = false;
            this.txt_id.Location = new System.Drawing.Point(308, 91);
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(360, 31);
            this.txt_id.TabIndex = 9;
            // 
            // txt_minute
            // 
            this.txt_minute.Location = new System.Drawing.Point(1569, 468);
            this.txt_minute.Name = "txt_minute";
            this.txt_minute.Size = new System.Drawing.Size(360, 31);
            this.txt_minute.TabIndex = 14;
            // 
            // cb_home
            // 
            this.cb_home.FormattingEnabled = true;
            this.cb_home.Location = new System.Drawing.Point(318, 215);
            this.cb_home.Name = "cb_home";
            this.cb_home.Size = new System.Drawing.Size(349, 33);
            this.cb_home.TabIndex = 17;
            this.cb_home.SelectedIndexChanged += new System.EventHandler(this.cb_home_SelectedIndexChanged);
            // 
            // cb_away
            // 
            this.cb_away.FormattingEnabled = true;
            this.cb_away.Location = new System.Drawing.Point(1168, 206);
            this.cb_away.Name = "cb_away";
            this.cb_away.Size = new System.Drawing.Size(349, 33);
            this.cb_away.TabIndex = 18;
            this.cb_away.SelectedIndexChanged += new System.EventHandler(this.cb_away_SelectedIndexChanged);
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Items.AddRange(new object[] {
            "GO",
            "GP",
            "GW",
            "CR",
            "CY",
            "PM"});
            this.cb_type.Location = new System.Drawing.Point(1580, 842);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(349, 33);
            this.cb_type.TabIndex = 19;
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(1569, 566);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(349, 33);
            this.cb_team.TabIndex = 20;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(1580, 708);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(349, 33);
            this.cb_player.TabIndex = 21;
            this.cb_player.SelectedIndexChanged += new System.EventHandler(this.cb_player_SelectedIndexChanged);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(1169, 99);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(356, 31);
            this.dateTimePicker1.TabIndex = 22;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(1442, 909);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(190, 56);
            this.btn_add.TabIndex = 23;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(1610, 1030);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(190, 56);
            this.btn_insert.TabIndex = 24;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(1774, 909);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(190, 56);
            this.btn_delete.TabIndex = 25;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2232, 1416);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.cb_away);
            this.Controls.Add(this.cb_home);
            this.Controls.Add(this.txt_minute);
            this.Controls.Add(this.txt_id);
            this.Controls.Add(this.dgv_detail);
            this.Controls.Add(this.lbl_type);
            this.Controls.Add(this.lbl_player);
            this.Controls.Add(this.lbl_team);
            this.Controls.Add(this.lbl_minute);
            this.Controls.Add(this.lbl_away);
            this.Controls.Add(this.lbl_date);
            this.Controls.Add(this.lbl_home);
            this.Controls.Add(this.lbl_id);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_detail)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_id;
        private System.Windows.Forms.Label lbl_home;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Label lbl_away;
        private System.Windows.Forms.Label lbl_minute;
        private System.Windows.Forms.Label lbl_team;
        private System.Windows.Forms.Label lbl_player;
        private System.Windows.Forms.Label lbl_type;
        private System.Windows.Forms.DataGridView dgv_detail;
        private System.Windows.Forms.TextBox txt_id;
        private System.Windows.Forms.TextBox txt_minute;
        private System.Windows.Forms.ComboBox cb_home;
        private System.Windows.Forms.ComboBox cb_away;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_insert;
        private System.Windows.Forms.Button btn_delete;
    }
}

